/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbdriver;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

/**
 *
 * @author SHREE
 */
public class EditProfile

{
     public boolean isUpdate(Statement st,String name,String mobile,String email ,String register,String specialit,String experience, String username ,String password )
    {
    boolean flag=false ;
    try
    {
       
        String query ="update doctor_registration_info set name='"+name+"',mobile_number='"+mobile+"',email_id='"+email +"',register_number='"+register+"',speciality='"+specialit+"',year_of_experience='"+experience+"',password='"+password+"' where username='"+username+"'" ;
        
        
        
        int x=st.executeUpdate(query);
        if(x>0)
            flag = true ;
        else
            flag = false ;
        
    }
    catch(Exception ex)
    {
        System.out.println("Exception is :"+ex);
    }
    return flag ;
}

}
