
package dbdriver;

import java.sql.Statement;
import java.sql.DriverManager ;
import java.sql.Connection ;
import java.sql.SQLException;




public class DBConnection

{
    public Statement getConnection() 
    {  
        
       Statement st=null ;
       try
       {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
             Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/healthcare","root","root");
              st=con.createStatement();
             
       }
       catch(Exception ex)
       {
           System.out.println("Exception Is :"+ex);
       }
       return st ;
    }
}
