/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbdriver;

import java.sql.Statement;


/**
 *
 * @author SHREE
 */
public class ViewPatientEdit

{
    public boolean isUpdate(Statement st,String name,String disease,String symptoms ,String medication,String suggestion )
    {
    boolean flag=false ;
    try
    {
       
        String query ="update patient_disease_info set disease='"+disease+"',symptoms='"+symptoms+"',medication='"+medication+"',suggestion='"+suggestion+"' where name='"+name+"'";
        
        
        System.out.println("Q is: "+query);
        int x=st.executeUpdate(query);
        if(x>0)
            flag = true ;
        else
            flag = false ;
        
        
    }
    catch(Exception ex)
    {
        System.out.println("Exception is :"+ex);
    }
    return flag ;
}
}
