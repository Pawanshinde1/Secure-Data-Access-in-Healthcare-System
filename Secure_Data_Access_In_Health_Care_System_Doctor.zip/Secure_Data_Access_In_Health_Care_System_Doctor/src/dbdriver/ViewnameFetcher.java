/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbdriver;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author SHREE
 */
public class ViewnameFetcher {
    
     public ArrayList getData(Statement st )
    {
        ArrayList data = new ArrayList();
        try
        {
             String query = " select * from patient_disease_info ";
             ResultSet rs=st.executeQuery(query);
             while(rs.next())
             {
             
                 String name=rs.getString(1);
                 data.add(name);
                 
                 
                 
                 
             }
                 
             System.out.println("data is: "+data);
                 
                 
        }
             catch(Exception ex)
                     {
                      System.out.println("Exception is :"+ex);
                     }
             return data ;
        }
    
}
