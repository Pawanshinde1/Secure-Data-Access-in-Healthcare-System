/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbdriver;

import java.sql.Statement;

/**
 *
 * @author hp
 */
public class Shared_Patient_Details {
   
    public boolean isInsert(Statement st,String from_doctor,String to_doctor,String name,String age,String gender,String address,String disease,String symptoms ,String medication,String suggestion)
    {
        boolean flag=false;
        try
        {
            String query = "insert into share_patient_data values('"+from_doctor+"','"+to_doctor+"','"+name+"','"+age+"','"+gender+"','"+address+"','"+disease+"','"+symptoms+"','"+medication+"','"+suggestion+"')";
             int x=st.executeUpdate(query);
            if(x>0)
                flag = true ;
               else
                  flag = false ;
        
        }
        catch(Exception ex)
        {
            System.out.println("Exception is:"+ex);
        }
        return flag;
    }
}
