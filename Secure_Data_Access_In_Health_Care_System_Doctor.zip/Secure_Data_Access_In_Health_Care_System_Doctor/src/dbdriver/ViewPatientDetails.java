/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbdriver;

import java.sql.ResultSet;
import java.sql.Statement;
import secure_data_access_in_health_care_system_doctor.ViewPatientDetailsTable;

/**
 *
 * @author hp
 */
public class ViewPatientDetails {
    public void getView_Patient_Details(String doctor_name)
    {
       
        try
        {
            Statement st1=new DBConnection().getConnection();
              Statement st2=new DBConnection().getConnection();
              
              String query="select * from patient_disease_info where doctor_name='"+doctor_name+"'";
              
              ResultSet rs1=st1.executeQuery(query);
              ResultSet rs2=st2.executeQuery(query);
             
              int row=0;
              while(rs1.next())
              {
                  row++;
              }
              int i=0;
              String data[][]= new String [row][8];
              while(rs2.next())
              {
                  String name=rs2.getString(1);
                  data[i][0]=name;
                  
                  String age=rs2.getString(2);
                  data[i][1]=age;
                  
                  String gender=rs2.getString(3);
                  data[i][2]=gender;
                  
                  String address=rs2.getString(4);
                  data[i][3]=address;
                  
                  String disease=rs2.getString(5);
                  data[i][4]=disease;
                  
                  String symptoms=rs2.getString(6);
                  data[i][5]=symptoms;
                  
                  String medication=rs2.getString(7);
                  data[i][6]=medication;
                  
                  String suggestion=rs2.getString(8);
                  data[i][7]=suggestion;
                  
                  i++;
                  
                  
              }
              ViewPatientDetailsTable.data1=data;
        }
        catch(Exception ex)
        {
            System.out.println("Exception is:"+ex);
                    
        }
    }
    
    
}
