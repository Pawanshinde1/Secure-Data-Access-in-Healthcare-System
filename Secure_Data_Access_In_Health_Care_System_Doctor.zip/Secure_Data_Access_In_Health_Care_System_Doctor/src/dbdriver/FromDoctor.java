/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbdriver;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author hp
 */
public class FromDoctor {
     public String getData(Statement st )
    {
        String to_doctor = "";
        try
        {
             String query = " select * from share_patient_data ";
             ResultSet rs=st.executeQuery(query);
             while(rs.next())
             {
             
                  to_doctor=rs.getString(2);
                
                 
                 
                 
                 
             }
                 
          //   System.out.println("data is: "+data);
                 
                 
        }
             catch(Exception ex)
                     {
                      System.out.println("Exception is :"+ex);
                     }
             return to_doctor ;
        }
    
}
