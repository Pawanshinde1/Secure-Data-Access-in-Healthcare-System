/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbdriver;

/**
 *
 * @author hp
 */
public class DataAttribute {
    
    public String getAttribute(String text)
    {
      
        System.out.println("text is: "+text);
          String cptext="";
             char ch=text.charAt(0);
               int x1=(int)ch;
                   System.out.println("First ASCII is: "+x1);
             
             if((int)ch>90)
             {
                 StringBuffer sb=new StringBuffer();
             
                 for(int i=0;i<text.length();i++)
               {
           
               char ch1 = text.charAt(i);
               int x=(int)ch1;
                   System.out.println("x is: "+x);
               x=x-50;
               char nc=(char)x;
               sb.append(nc);
             }
                 cptext=sb.toString();
             
         }
             else
             {
               
             
                 cptext=text;
                 
             }
             
                 
             
             return cptext;
}
}
