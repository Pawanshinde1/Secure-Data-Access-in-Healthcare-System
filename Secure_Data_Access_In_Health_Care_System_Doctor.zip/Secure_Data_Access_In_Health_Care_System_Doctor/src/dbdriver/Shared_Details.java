/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbdriver;

import java.sql.ResultSet;
import java.sql.Statement;
import secure_data_access_in_health_care_system_doctor.ViewPatientDetailsTable;
import secure_data_access_in_health_care_system_doctor.View_Patient_Shared_Data_Frame;

/**
 *
 * @author hp
 */
public class Shared_Details {
     public void getView_Patient_Shared_Details(String from_doctor)
    {
       
        try
        {
            Statement st1=new DBConnection().getConnection();
              Statement st2=new DBConnection().getConnection();
              
              String query="select * from share_patient_data where to_doctor='"+from_doctor+"'";
              
              ResultSet rs1=st1.executeQuery(query);
              ResultSet rs2=st2.executeQuery(query);
             
              int row=0;
              while(rs1.next())
              {
                  row++;
              }
              int i=0;
              String data[][]= new String [row][10];
              while(rs2.next())
              {
                    from_doctor=rs2.getString(1);
                  data[i][0]=from_doctor; 
                  
                   String to_doctor=rs2.getString(2);
                  data[i][1]=to_doctor;
                  
                  String name=rs2.getString(3);
                  data[i][2]=name;
                  
                  String age=rs2.getString(4);
                  data[i][3]=age;
                  
                  String gender=rs2.getString(5);
                  data[i][4]=gender;
                  
                  String address=rs2.getString(6);
                  data[i][5]=address;
                  
                  String disease=rs2.getString(7);
                  data[i][6]=disease;
                  
                  String symptoms=rs2.getString(8);
                  data[i][7]=symptoms;
                  
                  String medication=rs2.getString(9);
                  data[i][8]=medication;
                  
                  String suggestion=rs2.getString(10);
                  data[i][9]=suggestion;
                  
                  i++;
                  
                  
              }
              View_Patient_Shared_Data_Frame.data2=data;
        }
        catch(Exception ex)
        {
            System.out.println("Exception is:"+ex);
                    
        }
    }
}

