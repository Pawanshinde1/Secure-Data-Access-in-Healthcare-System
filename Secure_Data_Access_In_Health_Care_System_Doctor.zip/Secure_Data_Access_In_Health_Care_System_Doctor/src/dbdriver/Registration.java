
package dbdriver;

import java.sql.Statement;


public class Registration 

{
    public boolean isInsert(Statement st,String name,String mobile,String email ,String register,String specialit,String experience, String username ,String password )
    {
    boolean flag=false ;
    try
    {
        String query = "insert into doctor_registration_info values('"+name+"','"+mobile+"','"+email+"','"+register+"','"+specialit+"','"+experience+"','"+username+"','"+password+"')";
        int x=st.executeUpdate(query);
        if(x>0)
            flag = true ;
        else
            flag = false ;
        
    }
    catch(Exception ex)
    {
        System.out.println("Exception is :"+ex);
    }
    return flag ;
}

}