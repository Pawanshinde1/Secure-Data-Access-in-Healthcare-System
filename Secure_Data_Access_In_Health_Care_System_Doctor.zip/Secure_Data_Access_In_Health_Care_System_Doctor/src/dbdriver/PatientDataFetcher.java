/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbdriver;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import static secure_data_access_in_health_care_system_doctor.EditProfileFrame.username;

/**
 *
 * @author SHREE
 */
public class PatientDataFetcher

{
   public ArrayList getData(Statement st,String username )
    {
        ArrayList data = new ArrayList();
        try
        {
            String query = " select * from registration_info where username='"+username+"'";
            
             ResultSet rs=st.executeQuery(query);
             if(rs.next())
             {
                 String name=rs.getString(1);
                // String mobile_number=rs.getString(2);
               //  String email=rs.getString(3);
                 String gender=rs.getString(4);
                 String age=rs.getString(5);
                 String address=rs.getString(6);
               //  String password=rs.getString(8);
                 
                 data.add(name);
                // data.add(mobile_number);
               //  data.add(email);
                 data.add(gender );
                 data.add(age);
                 data.add( address);
                 
                 //data.add(password);

                 
              }
                 
        }
             catch(Exception ex)
                     {
                      System.out.println("Exception is :"+ex);
                     }
             return data ;
        }


    
    
}
