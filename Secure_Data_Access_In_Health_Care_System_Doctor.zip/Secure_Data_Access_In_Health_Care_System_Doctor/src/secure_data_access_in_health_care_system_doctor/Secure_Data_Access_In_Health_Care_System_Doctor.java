/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package secure_data_access_in_health_care_system_doctor;

import java.awt.Dimension;
import java.awt.Toolkit;

/**
 *
 * @author SHREE
 */
public class Secure_Data_Access_In_Health_Care_System_Doctor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    
    {
      Main_Frame mf=new  Main_Frame();
      Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
      mf.setVisible(true);
      mf.setSize(d);
    }
    
}
