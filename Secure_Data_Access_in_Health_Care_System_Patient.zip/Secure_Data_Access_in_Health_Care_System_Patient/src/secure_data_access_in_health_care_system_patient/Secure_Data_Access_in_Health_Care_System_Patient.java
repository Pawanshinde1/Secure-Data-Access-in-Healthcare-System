/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package secure_data_access_in_health_care_system_patient;

import java.awt.Dimension;
import java.awt.Toolkit;

/**
 *
 * @author hp
 */
public class Secure_Data_Access_in_Health_Care_System_Patient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Main_Frame mf=new Main_Frame();
        Dimension d=Toolkit.getDefaultToolkit().getScreenSize();
         mf.setVisible(true);
         mf.setSize(d);
        
    }
    
}
