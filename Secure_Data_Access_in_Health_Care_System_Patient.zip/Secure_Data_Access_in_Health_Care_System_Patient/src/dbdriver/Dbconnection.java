 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbdriver;

/**
 *
 * @author hp
 */
import java.sql.*;
public class Dbconnection {
    
     public Statement getConnection()
             
     {
         Statement st=null;
        try
        {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/healthcare","root","root");
            st=conn.createStatement();
        }
        catch(Exception ex)
        {
            System.out.println("Exception is:"+ex);
        }
        return st;
     }
    
}
