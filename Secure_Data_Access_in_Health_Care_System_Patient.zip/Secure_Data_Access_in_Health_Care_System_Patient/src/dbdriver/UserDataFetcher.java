/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbdriver;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author hp
 */
public class UserDataFetcher
{
    public ArrayList getData(Statement st,String username)
    {
        ArrayList data=new ArrayList();
        try
        {
            String query="select * from registration_info where username='"+username+"'";
            ResultSet rs=st.executeQuery(query);
            
            if(rs.next())
            {
                String name=rs.getString(1);
                String mobile=rs.getString(2);
                String email=rs.getString(3);
                String gender=rs.getString(4);
                String age=rs.getString(5);
                String address=rs.getString(6);
                String password=rs.getString(8);
                
                data.add(name);
                data.add(mobile);
                data.add(email);
                data.add(gender);
                data.add(age);
                data.add(address);
                 data.add(username);
                data.add(password);
                
            }
        }
        catch(Exception ex)
        {
            System.out.println("Exception is:"+ex);
        }
        return data;
    }
    
}
