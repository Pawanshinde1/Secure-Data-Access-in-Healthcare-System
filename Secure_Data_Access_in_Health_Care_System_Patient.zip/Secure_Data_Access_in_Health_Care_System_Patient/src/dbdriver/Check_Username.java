/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbdriver;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author hp
 */
public class Check_Username {
    
    public Boolean checkusername(Statement st,String username)
    {
       boolean flag=false;
        try
        {
            String query="select * from registration_info where username='"+username+"'";
            ResultSet rs=st.executeQuery(query);
            if(rs.next())
                flag=true;
            else
                flag=false;
                   
            
        } 
        catch(Exception ex)
        {
            System.out.println("Exception is:"+ex);
        
    }
    
    return flag;
    }
}
