/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbdriver;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author hp
 */
public class Patient_Disease_DataFetcher {
    
    public ArrayList getData(Statement st,String name)
    {
        ArrayList data=new ArrayList();
           try
           {
               String query="select * from patient_disease_info where name='"+name+"' ";
                  ResultSet rs=st.executeQuery(query);  
                  
                  if(rs.next())
                  {
                    name=rs.getString(1);
                   String age=rs.getString(2);
                   String gender=rs.getString(3);
                   String address=rs.getString(4);
                   String disease=rs.getString(5);
                   String symptoms=rs.getString(6);
                   String medication=rs.getString(7);
                   String suggestion=rs.getString(8);
                   String doctor_name=rs.getString(9);

                data.add(name);
                data.add(age);
                data.add(gender);
                data.add(address);
                data.add(disease);
                data.add(symptoms);
                data.add(medication);
                data.add(suggestion);
                data.add(doctor_name);
                
                
       
                
                  }
                  
                  System.out.println(data);
           }
           catch(Exception ex)
           {
               System.out.println("Exception is:"+ex);
           }
           return  data;
    }
           
}
    
